package com.portfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioBeckendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfolioBeckendApplication.class, args);
	}

}
